package bbs;

import java.sql.*;
import java.util.*;

public class BbsDAO {
 
	Connection conn = null;
	PreparedStatement pstmt = null;
	
	
			String jdbc_url="jdbc:oracle:thin:@localhost:1521:orcl";
			String jdbc_driver="oracle.jdbc.driver.OracleDriver";
		
	
   	 void connect() { 
	   	  try { 
	   	    Class.forName(jdbc_driver); 
	   	     
	   	    conn = DriverManager.getConnection(jdbc_url,"hani","dbpass"); 
	   	  } catch (Exception e) { 
	   	   e.printStackTrace(); 
	  			} 
	  	} 
	   	  
	   	 void disconnect() { 
	  	  if(pstmt !=null) { 
			    try { 
	  	      pstmt.close(); 
	  	    } catch (Exception e) { 
	  	      e.printStackTrace(); 
	  	    } 
	  	  } 
	  	if(conn != null) {
			try {
				conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	 	 
	   	 
	   	 
	   	 
	   	 //수정된 글 내용 갱신을 위한 메서드
	   	 
	   	 
	   	public boolean updateDB(Bbs tb_bbs) {
			 String SQL ="UPDATE tb_bbs SET bbsTitle =?, bbsContent =? WHERE bbsID =? ";
			  try {
				  pstmt = conn.prepareStatement(SQL);
				  pstmt.setString(1, tb_bbs.getBbsTitle());
				  pstmt.setString(2, tb_bbs.getBbsContent());
				  pstmt.setInt(3, tb_bbs.getBbsID());
				  pstmt.executeUpdate();
			  } catch (Exception e) {
					e.printStackTrace();
			  }
					finally {
						disconnect();
					}
					return true;
				}
	   	
	   	// 특정 게시물 삭제
		public boolean deleteDB(int bbsID) {
			connect();
			 String SQL ="delete from tb_bbs WHERE bbsID =?";
			  try {
				  pstmt = conn.prepareStatement(SQL);
				  pstmt.setInt(1, bbsID);
				  pstmt.executeUpdate();
				} catch (Exception e) {
					e.printStackTrace();
					return false;
				}
				finally {
					disconnect();
				}
				return true;
			}
	   	 
		
		//신규 게시물 메시지 추가 메서드
		
		public boolean insertDB(Bbs bbs){ 
			connect(); 
			
			 String SQL ="INSERT INTO tb_bbs(bbsID, bbsTitle, userID, bbsContent) VALUES (bbs_seq_id.nextval, ?, ?, ?)";
			  try {
				  pstmt = conn.prepareStatement(SQL);
				  pstmt.setString(1, bbs.getBbsTitle());
				  pstmt.setString(2, bbs.getUserID());
				  pstmt.setString(3, bbs.getBbsContent());
				  pstmt.executeQuery();
				  
			  } catch (Exception e) {
					e.printStackTrace();
					return false;
				}
				finally {
					disconnect();
				}
				return true;
			}

		
		
		
		public Bbs getDB(int bbsID) {
			
			connect();
			
			String SQL = "SELECT * FROM tb_bbs WHERE bbsID = ?";
		
			 Bbs bbs = new Bbs();
			
			try {
				  pstmt = conn.prepareStatement(SQL);
				  pstmt.setInt(1, bbsID);
				  ResultSet rs = pstmt.executeQuery();
				  
				 if(rs.next()) {
					 
					 bbs.setBbsID(rs.getInt("bbsID"));
					 bbs.setBbsTitle(rs.getString("bbsTitle"));
					 bbs.setUserID(rs.getString("userId"));
					 bbs.setBbsDate(rs.getString("bbsDate"));
					 bbs.setBbsContent(rs.getString("bbsContent"));
					rs.close();
				 }
			}catch(Exception e) {
				e.printStackTrace();
			}finally {
				disconnect();
			}
			return bbs;
		}
		
		
		public ArrayList<Bbs> getDBList(){
			connect();
			ArrayList<Bbs> datas = new ArrayList<Bbs>();
			String sql = "SELECT * FROM tb_bbs order by bbsID desc";
			try {
				  pstmt = conn.prepareStatement(sql);
				  ResultSet rs = pstmt.executeQuery(); 
				  while(rs.next()) { 

					 Bbs bbs = new Bbs();
					 bbs.setBbsID(rs.getInt("bbsID"));
					 bbs.setBbsTitle(rs.getString("bbsTitle"));
					 bbs.setUserID(rs.getString("userID"));
					 bbs.setBbsDate(rs.getString("bbsDate"));
					 datas.add(bbs);
				  }
			}catch(Exception e) {
				e.printStackTrace();
			}finally {
				disconnect();
			}
			return datas;
		}


public Bbs getBbs(int bbsID) {
	connect();
	
	String SQL = "SELECT * FROM tb_bbs WHERE bbsID = ?";
	try {
		  pstmt = conn.prepareStatement(SQL);
		  pstmt.setInt(1, bbsID);
		  ResultSet rs = pstmt.executeQuery();
		  
		 if(rs.next()) {	 
			 Bbs bbs = new Bbs();
			 bbs.setBbsID(rs.getInt(1));
			 bbs.setBbsTitle(rs.getString(2));
			 bbs.setUserID(rs.getString(3));
			 bbs.setBbsDate(rs.getString(4));
			 bbs.setBbsContent(rs.getString(5));
			 return bbs;
		 }
	}catch(Exception e) {
		e.printStackTrace();
	}
	return null;
}
	
}
			
		