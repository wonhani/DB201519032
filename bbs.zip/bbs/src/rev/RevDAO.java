package rev;

import java.sql.*;
import java.util.*;

public class RevDAO {
 
	Connection conn = null;
	PreparedStatement pstmt = null;
	
	
			String jdbc_url="jdbc:oracle:thin:@localhost:1521:orcl";
			String jdbc_driver="oracle.jdbc.driver.OracleDriver";
		
	
   	 void connect() { 
	   	  try { 
	   	    Class.forName(jdbc_driver); 
	   	     
	   	    conn = DriverManager.getConnection(jdbc_url,"hani","dbpass"); 
	   	  } catch (Exception e) { 
	   	   e.printStackTrace(); 
	  			} 
	  	} 
	   	  
	   	 void disconnect() { 
	  	  if(pstmt !=null) { 
			    try { 
	  	      pstmt.close(); 
	  	    } catch (Exception e) { 
	  	      e.printStackTrace(); 
	  	    } 
	  	  } 
	  	if(conn != null) {
			try {
				conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	 	 
	   	 
	   	 
	   	 
	   	 //수정된 글 내용 갱신을 위한 메서드
	   	 
	   	 
	   	public boolean updateDB(Rev re_bbs) {
			 String SQL ="UPDATE re_bbs SET bbsTitle =?, bbsContent =? WHERE bbsID =? ";
			  try {
				  pstmt = conn.prepareStatement(SQL);
				  pstmt.setString(1, re_bbs.getBbsTitle());
				  pstmt.setString(2, re_bbs.getBbsContent());
				  pstmt.setInt(3, re_bbs.getBbsID());
				  pstmt.executeUpdate();
			  } catch (Exception e) {
					e.printStackTrace();
			  }
					finally {
						disconnect();
					}
					return true;
				}
	   	
	   	// 특정 게시물 삭제
		public boolean deleteDB(int bbsID) {
			connect();
			 String SQL ="delete from re_bbs WHERE bbsID =?";
			  try {
				  pstmt = conn.prepareStatement(SQL);
				  pstmt.setInt(1, bbsID);
				  pstmt.executeUpdate();
				} catch (Exception e) {
					e.printStackTrace();
					return false;
				}
				finally {
					disconnect();
				}
				return true;
			}
	   	 
		
		//신규 게시물 메시지 추가 메서드
		
		public boolean insertDB(Rev rev){ 
			connect(); 
			
			 String SQL ="INSERT INTO re_bbs(bbsID, bbsTitle, userID, bbsContent) VALUES (bbs_seq_id.nextval, ?, ?, ?)";
			  try {
				  pstmt = conn.prepareStatement(SQL);
				  pstmt.setString(1, rev.getBbsTitle());
				  pstmt.setString(2, rev.getUserID());
				  pstmt.setString(3, rev.getBbsContent());
				  pstmt.executeQuery();
				  
			  } catch (Exception e) {
					e.printStackTrace();
					return false;
				}
				finally {
					disconnect();
				}
				return true;
			}

		
		
		
		public Rev getDB(int bbsID) {
			
			connect();
			
			String SQL = "SELECT * FROM re_bbs WHERE bbsID = ?";
		
			 Rev rev = new Rev();
			
			try {
				  pstmt = conn.prepareStatement(SQL);
				  pstmt.setInt(1, bbsID);
				  ResultSet rs = pstmt.executeQuery();
				  
				 if(rs.next()) {
					 
					 rev.setBbsID(rs.getInt("bbsID"));
					 rev.setBbsTitle(rs.getString("bbsTitle"));
					 rev.setUserID(rs.getString("userId"));
					 rev.setBbsDate(rs.getString("bbsDate"));
					 rev.setBbsContent(rs.getString("bbsContent"));
					rs.close();
				 }
			}catch(Exception e) {
				e.printStackTrace();
			}finally {
				disconnect();
			}
			return rev;
		}
		
		
		public ArrayList<Rev> getDBList(){
			connect();
			ArrayList<Rev> lst = new ArrayList<Rev>();
			String sql = "SELECT * FROM re_bbs order by bbsID desc";
			try {
				  pstmt = conn.prepareStatement(sql);
				  ResultSet rs = pstmt.executeQuery(); 
				  while(rs.next()) { 

					 Rev rev = new Rev();
					 rev.setBbsID(rs.getInt("bbsID"));
					 rev.setBbsTitle(rs.getString("bbsTitle"));
					 rev.setUserID(rs.getString("userID"));
					 rev.setBbsDate(rs.getString("bbsDate"));
					 lst.add(rev);
				  }
			}catch(Exception e) {
				e.printStackTrace();
			}finally {
				disconnect();
			}
			return lst;
		}


public Rev getBbs(int bbsID) {
	connect();
	
	String SQL = "SELECT * FROM re_bbs WHERE bbsID = ?";
	try {
		  pstmt = conn.prepareStatement(SQL);
		  pstmt.setInt(1, bbsID);
		  ResultSet rs = pstmt.executeQuery();
		  
		 if(rs.next()) {	 
			 Rev rev = new Rev();
			 rev.setBbsID(rs.getInt(1));
			 rev.setBbsTitle(rs.getString(2));
			 rev.setUserID(rs.getString(3));
			 rev.setBbsDate(rs.getString(4));
			 rev.setBbsContent(rs.getString(5));
			 return rev;
		 }
	}catch(Exception e) {
		e.printStackTrace();
	}
	return null;
}
	
}
			
		